<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use App\Models\Fornecedor;
use Illuminate\Support\Facades\DB;

class FornecedorController extends Controller
{
    public function index() {

        $fornecedor = DB::table('fornecedor')->orderBy('razão social', 'asc')->get();
        $fornecedor = json_decode($fornecedor, true);
        return view('fornecedor.index', 
        ['fornecedor' => $fornecedor]); //select * from fornecedor
    }
    
    //função que irá retornar a tela do form
    public function create() {
        return view("fornecedor.create");
    }

    public function store(Request $request) {
        //dd($request->all());

        $request->validate([
            'razão social' => 'required|min:2|max:50',
            'endereço' => 'required|min:2|max:50',
        ]);
        
        Fornecedor::create([
            'razão social' => $request->razãosocial,
            'endereço' => $request->endereço,
            'cidade' => $request->cidade,
            'estado' => $request->estado,
            'cep' => $request->cep,
        ]);
        return redirect('/fornecedor')->with('success', 'Fornecedor salvo com sucesso!');
    }

    public function edit($id)
    {
        $fornecedor = Fornecedor::find($id);
        return view('fornecedor.edit', ['fornecedor' => $fornecedor]);
    }
    public function update(Request $request)
    {
        $fornecedor = Fornecedor::find($request->id);
        $fornecedor->update([
            'razão social' => $request->razãosocial,
            'endereço' => $request->endereço,
            'cidade' => $request->cidade,
            'estado' => $request->estadp,
            'cep' => $request->cep
        ]);
        return redirect('/fornecedor');
    }

    public function destroy($id)
    {
        $fornecedor = Fornecedor::find($id);
        $fornecedor->delete();
        return redirect('/fornecedor');
    }
}
