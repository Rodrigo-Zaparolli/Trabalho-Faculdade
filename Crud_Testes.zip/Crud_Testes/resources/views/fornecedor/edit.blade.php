<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Fornecedor</title>
</head>

<body>
    <form action="{{ url('fornecedor/editar') }}" method="POST">
        @csrf
        <!-- campo oculto passando o ID como parâmetro no request -->
        <input type="hidden" name="id" value="{{ $fornecedor['id'] }}">
        <label>Razão Social:</label><br> <!-- valor preenchido -->
        <input name="razão social" type="text" value="{{ $fornecedor['razãosocial'] }}" /><br>
        <label>Endereço:</label><br> <!-- valor preenchido -->
        <input name="endereço" type="text" value="{{ $fornecedor['endereço'] }}" /><br>
        <label>Cidade:</label><br> <!-- valor preenchido -->
        <input name="cidade" type="text" value="{{ $fornecedor['cidade'] }}" /><br>
        <label>Estado:</label><br> <!-- valor preenchido -->
        <input name="estado" type="text" value="{{ $fornecedor['estado'] }}" /><br>
        <label>Cep:</label><br> <!-- valor preenchido -->
        <input name="cep" type="text" value="{{ $fornecedor['cep'] }}" /><br>
        <input type="submit" value="Salvar" />
    </form>
</body>

</html>