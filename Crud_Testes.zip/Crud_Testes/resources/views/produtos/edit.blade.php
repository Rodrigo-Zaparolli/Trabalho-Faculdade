<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar produtos</title>
</head>

<body>
    <form action="{{ url('produtos/editar') }}" method="POST">
        @csrf
        <!-- campo oculto passando o ID como parâmetro no request -->
        <input type="hidden" name="id" value="{{ $produto['id'] }}">
        <label>Descrição:</label><br> <!-- valor preenchido -->
        <input name="descrição" type="text" value="{{ $produto['descrição'] }}" /><br>
        <label>Referência:</label><br> <!-- valor preenchido -->
        <input name="referência" type="text" value="{{ $produto['referência'] }}" /><br>
        <label>Categoria:</label><br> <!-- valor preenchido -->
        <input name="categoria" type="text" value="{{ $produto['categoria'] }}" /><br>
        <input type="submit" value="Salvar" />
    </form>
</body>

</html>