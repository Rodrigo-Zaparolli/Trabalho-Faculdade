<x-guest-layout>
    <div class="max-w-6xl mx-auto">
        <h1 class="text-2xl font-semibold">Create Product</h1>

        <div class="mt-2">
            <a href="{{ route('products.index') }}" class="px-4 py-3 rounded bg-green-400">Back</a>
        </div>

        <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg mt-6">
            <div class="p-6 bg-white border-b border-gray-200">
                <h1 class="text-xl">{{ __('Create Product') }}</h1>

                <form method="POST" action="{{ route('products.store') }}">
                    @csrf

                    <div class="mt-4">
                        <label for="name" class="block">Name</label>
                        <input id="name" class="block mt-1 w-full" type="text" name="name" value="{{ old('name') }}" />
                    </div>

                    <div class="mt-4">
                        <label for="type" class="block">Type</label>
                        <input id="type" class="block mt-1 w-full" type="text" name="type" value="{{ old('type') }}" />
                    </div>

                    <div class="mt-4">
                        <label for="price" class="block">Price</label>
                        <input id="price" class="block mt-1 w-full" type="text" name="price" />
                    </div>

                    <div class="flex items-center justify-end mt-4">
                        <button class="px-4 py-2 rounded bg-blue-500 text-white">{{ __('Create') }}</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</x-guest-layout>