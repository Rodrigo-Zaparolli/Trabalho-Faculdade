<?php

use App\Http\Controllers\ProfileController;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\FornecedorController;
use App\Http\Controllers\ProdutosController;
use App\Http\Controllers\LoginController;
use App\Http\Controllers\ProductController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('products', [ProductController::class, 'index'])->name('products.index');
Route::get('products/create', [ProductController::class, 'create'])->middleware('admin')->name('products.create');
Route::post('products', [ProductController::class, 'store'])->middleware('admin')->name('products.store');
Route::get('products/{product:id}/edit', [ProductController::class, 'edit'])->middleware('admin')->name('products.edit');
Route::put('products/{product:id}', [ProductController::class, 'update'])->middleware('admin')->name('products.update');
Route::delete('products/{product:id}', [ProductController::class, 'destroy'])->middleware('admin')->name('products.destroy');


Route::get('/', function () {
    return view('login');
});

Route::get('/welcome', function () {
    return view('welcome');
})->middleware(['auth', 'verified'])->name('dashboard');

Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});

require __dir__.'/auth.php';

Route::post('/login', [LoginController::class, 'authenticate']);
Route::get('/logout', [LoginController::class, 'logout']);

Route::get('/fornecedor', [FornecedorController::class, 'index'])->middleware('auth.basic');
Route::get('/fornecedor/novo', [FornecedorController::class, 'create'])->middleware('auth.basic');
Route::post('/fornecedor/novo', [FornecedorController::class, 'store'])->middleware('auth.basic');

Route::get('/fornecedor/delete/{id}', [FornecedorController::class, 'destroy'])->middleware('auth.basic');
Route::get('/fornecedor/editar/{id}', [FornecedorController::class, 'edit'])->middleware('auth.basic');
Route::post('/fornecedor/editar/', [FornecedorController::class, 'update'])->middleware('auth.basic');

Route::get('/produtos', [ProdutosController::class, 'index'])->middleware('auth.basic');
Route::get('/produtos/novo', [ProdutosController::class, 'create'])->middleware('auth.basic');
Route::post('/produtos/novo', [ProdutosController::class, 'store'])->middleware('auth.basic');

Route::get('/produtos/delete/{id}', [ProdutosController::class, 'destroy'])->middleware('auth.basic');
Route::get('/produtos/editar/{id}', [ProdutosController::class, 'edit'])->middleware('auth.basic');
Route::post('/produtos/editar/', [ProdutosController::class, 'update'])->middleware('auth.basic');



