<?php if (isset($component)) { $__componentOriginal69dc84650370d1d4dc1b42d016d7226b = $component; } ?>
<?php $component = App\View\Components\GuestLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\GuestLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="max-w-6xl mx-auto">
        <h1 class="text-2xl font-semibold">Update Product</h1>

        <div class="mt-2">
            <a href="<?php echo e(route('products.index')); ?>" class="px-4 py-3 rounded bg-green-400">Back</a>
        </div>

        <form method="POST" action="<?php echo e(route('products.update', $product->id)); ?>">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <div class="mt-4">
                <label for="name" class="block">Name</label>
                <input id="name" class="block mt-1 w-full" type="text" name="name" value="<?php echo e($product->name); ?>" />
            </div>

            <div class="mt-4">
                <label for="type" class="block">Type</label>
                <input id="type" class="block mt-1 w-full" type="text" name="type" value="<?php echo e($product->type); ?>" />
            </div>

            <div class="mt-4">
                <label for="price" class="block">Price</label>
                <input id="price" class="block mt-1 w-full" type="text" name="price" value="<?php echo e($product->price); ?>" />
            </div>

            <div class="flex items-center justify-end mt-4">
                <button class="px-4 py-2 rounded bg-blue-500 text-white">Update</button>
            </div>
        </form>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b)): ?>
<?php $component = $__componentOriginal69dc84650370d1d4dc1b42d016d7226b; ?>
<?php unset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b); ?>
<?php endif; ?><?php /**PATH C:\Users\rodri\Desktop\Crud_Testes\resources\views/products/edit.blade.php ENDPATH**/ ?>