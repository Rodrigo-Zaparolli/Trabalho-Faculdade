

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">
       <h2>Cadastro de alunos</h2> 
    </div>
    <div class="card-body">
        <div class="row">
            <div class="col">
                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <strong>Problemas com seus dados:</strong>
                        <br>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li> <?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <div class="row">
            <form action="<?php echo e(url('alunos/novo')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <strong>Nome:</strong>
                    <input placeholder="Digite o nome" class="form-control mb-3" name="nome" type="text" />
                    <strong>Idade:</strong>
                    <input placeholder="Digite a idade" class="form-control mb-3" name="idade" type="number" />
                    <strong>Email:</strong>
                    <input placeholder="Digite o email" class="form-control mb-3" name="email" type="text" />

                    <div class="col">
                        <a class="btn btn-secondary" href="<?php echo e(url('/alunos')); ?>">Voltar</a>
                    </div>
                    <div class="col">
                        <button class="btn btn-primary" type="submit">Salvar</button>
                    </div>

                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('crud_template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\crud-ads\resources\views/alunos/create.blade.php ENDPATH**/ ?>